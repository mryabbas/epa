# complete the gap to agree with the user's colour choice!
colour = input("What is your favourite colour? ")
print("I also like", ______)