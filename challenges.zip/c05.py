rolls = [1, 4, 3, 6]
selection = []
for dice in rolls:
  if dice > 3:
    selection.append(dice)

print(selection)

