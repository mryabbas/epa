rolls = [1, 4, 3, 6]
count = 0
for dice in rolls:
  if dice > 3:
    count = count + 1


print(count)
