rolls = [1, 4, 3, 6]
for dice in rolls:
  print(dice)
