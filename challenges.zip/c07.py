from data import dictionary
nb_words = len(dictionary)       
print(nb_words, "english words in the list")