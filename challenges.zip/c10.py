from data import dictionary
longest = ""
for word in dictionary:
  if                               :  # <<< MISSING 
    longest = word
print(longest)
