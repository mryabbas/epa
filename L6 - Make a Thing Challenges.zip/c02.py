sentence = input()
vowel_count = 0
vowel_count = vowel_count + 1
vowels = "aeiouAEIOU"
print(vowel_count, "vowels in this sentence")
print("Enter a sentence:")
if character in sentence:
for character in sentence:
