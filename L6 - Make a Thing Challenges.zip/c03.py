number = input()
sum = 0
sum = sum + ???
print("Sum of digits in", number, "is", sum)
print("Enter a number:")
for ??? in ???:
digit = int(character)
