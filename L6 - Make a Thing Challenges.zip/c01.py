numbers = [2, 4, 8, 16]
sum = 1
number = numbers[0]
sum = sum + number	
 
number = numbers[1]
sum = sum + number	
 
number = numbers[2]
sum = sum + number	

number = numbers[3]
sum = sum + number	
print(sum)
